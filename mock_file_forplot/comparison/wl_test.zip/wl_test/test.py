import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate
import math

outroot = 'results/'

color_1 = (203.0/255.0, 15.0/255.0, 40.0/255.0)
color_2 = (255.0/255.0, 165.0/255.0, 0.0)
color_3 = (42.0/255.0, 46.0/255.0, 139.0/255.0)

# load results:
marco = np.loadtxt('test_Euclid_fiducial.dat')

stefano_11 = np.loadtxt('C^k_l-CFHTLenS-11.dat')
stefano_21 = np.loadtxt('C^k_l-CFHTLenS-12.dat')
stefano_22 = np.loadtxt('C^k_l-CFHTLenS-22.dat')

winny_11 = np.loadtxt('C11-Case1-Winny.dat')
winny_21 = np.loadtxt('C12-Case1-Winny.dat')
winny_22 = np.loadtxt('C22-Case1-Winny.dat')

martin   = np.loadtxt('Martin.dat')

# interpolate results:
marco_11_interp   = interpolate.InterpolatedUnivariateSpline(marco[:,0], marco[:,1])
stefano_11_interp = interpolate.InterpolatedUnivariateSpline(stefano_11[:,0], stefano_11[:,1])
winny_11_interp   = interpolate.InterpolatedUnivariateSpline(winny_11[:,0], winny_11[:,1])
martin_11_interp  = interpolate.InterpolatedUnivariateSpline( martin[:,0], (2.0*math.pi)*martin[:,1]/(martin[:,0]*(martin[:,0]+1.0)) )

marco_21_interp   = interpolate.InterpolatedUnivariateSpline(marco[:,0], marco[:,2])
stefano_21_interp = interpolate.InterpolatedUnivariateSpline(stefano_21[:,0], stefano_21[:,1])
winny_21_interp   = interpolate.InterpolatedUnivariateSpline(winny_21[:,0], winny_21[:,1])
martin_21_interp  = interpolate.InterpolatedUnivariateSpline(martin[:,0], (2.0*math.pi)*martin[:,2]/(martin[:,0]*(martin[:,0]+1.0)))

marco_22_interp   = interpolate.InterpolatedUnivariateSpline(marco[:,0], marco[:,4])
stefano_22_interp = interpolate.InterpolatedUnivariateSpline(stefano_22[:,0], stefano_22[:,1])
winny_22_interp   = interpolate.InterpolatedUnivariateSpline(winny_22[:,0], winny_22[:,1])
martin_22_interp  = interpolate.InterpolatedUnivariateSpline(martin[:,0], (2.0*math.pi)*martin[:,3]/(martin[:,0]*(martin[:,0]+1.0)))

# get the l:
l_min = np.amax( [ np.amin(marco[:,0]), np.amin(stefano_11[:,0]), np.amin(winny_11[:,0]), np.amin(martin[:,0]) ] )
l_max = np.amin( [ np.amax(marco[:,0]), np.amax(stefano_11[:,0]), np.amax(winny_11[:,0]), np.amax(martin[:,0]) ] )

x = np.linspace(l_min, l_max, l_max-l_min)

# plot 1:
plt.plot( x, np.abs( marco_11_interp(x)-stefano_11_interp(x))/np.abs(stefano_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( marco_21_interp(x)-stefano_21_interp(x))/np.abs(stefano_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( marco_22_interp(x)-stefano_22_interp(x))/np.abs(stefano_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Marco VS Stefano')
plt.savefig(outroot+'MR_VS_SC.pdf')
plt.clf()

# plot 2:
plt.plot( x, np.abs( marco_11_interp(x)-winny_11_interp(x))/np.abs(winny_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( marco_21_interp(x)-winny_21_interp(x))/np.abs(winny_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( marco_22_interp(x)-winny_22_interp(x))/np.abs(winny_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Marco VS Vincenzo')
plt.savefig(outroot+'MR_VS_VC.pdf')
plt.clf()

# plot 3:
plt.plot( x, np.abs( stefano_11_interp(x)-winny_11_interp(x))/np.abs(winny_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( stefano_21_interp(x)-winny_21_interp(x))/np.abs(winny_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( stefano_22_interp(x)-winny_22_interp(x))/np.abs(winny_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Stefano VS Vincenzo')
plt.savefig(outroot+'SC_VS_VC.pdf')
plt.clf()

# plot 4:
plt.plot( x, np.abs( stefano_11_interp(x)-martin_11_interp(x))/np.abs(martin_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( stefano_21_interp(x)-martin_21_interp(x))/np.abs(martin_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( stefano_22_interp(x)-martin_22_interp(x))/np.abs(martin_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Stefano VS Martin')
plt.savefig(outroot+'SC_VS_MK.pdf')
plt.clf()

# plot 5:
plt.plot( x, np.abs( winny_11_interp(x)-martin_11_interp(x))/np.abs(martin_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( winny_21_interp(x)-martin_21_interp(x))/np.abs(martin_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( winny_22_interp(x)-martin_22_interp(x))/np.abs(martin_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Vincenzo VS Martin')
plt.savefig(outroot+'VC_VS_MK.pdf')
plt.clf()

# plot 6:
plt.plot( x, np.abs( martin_11_interp(x)-marco_11_interp(x))/np.abs(marco_11_interp(x))*100.0, label='11', c=color_1 )
plt.plot( x, np.abs( martin_21_interp(x)-marco_21_interp(x))/np.abs(marco_21_interp(x))*100.0, label='12', c=color_2 )
plt.plot( x, np.abs( martin_22_interp(x)-marco_22_interp(x))/np.abs(marco_22_interp(x))*100.0, label='22', c=color_3 )

plt.xscale('log')
plt.yscale('log')

plt.xlabel('$\\ell$')
plt.ylabel('$\\Delta C_{\\ell} / C_{\\ell} \%$')

plt.xlim([l_min, l_max])
plt.legend()
plt.suptitle('Martin VS Marco')
plt.savefig(outroot+'MK_VS_MR.pdf')
plt.clf()
